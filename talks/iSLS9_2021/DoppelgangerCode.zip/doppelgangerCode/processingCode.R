#clean up dataset to make it easy to understand
rc = as.data.frame(readxl::read_excel("data/140604ktc12_ktb36_wilson.xlsx", sheet = "ktb36"))
rc_details = as.data.frame(readxl::read_excel("data/140604ktc12_ktb36_wilson.xlsx", sheet = "ktb36 annotation"))
#change rowname
rownames(rc) = rc$prot
#remove excess colnames
rc$prot = NULL
rc$pepSeqNum = NULL
rc$tgNum = NULL
#change colnames
new_col_names = NULL
old_col_names = colnames(rc)
for (i in 1:ncol(rc)){
  col = old_col_names[i]
  new_col_names[i] = rc_details[(rc_details$SWATH_file_name==col),"Reannotation"]
}
colnames(rc) = new_col_names
rc = rc[,rc_details$Reannotation]
#Remove unnecessary information
rc_details$SWATH_file_name = NULL
rownames(rc_details) = rc_details$Reannotation
rc_details$Reannotation = NULL
rc_details$Ktb36 = NULL
colnames(rc_details) = c("Sample_ID", "Class", "Patient_ID", "Replicate", "Tumour_Histological_Type")
rc_details = rc_details[, c("Class","Tumour_Histological_Type","Patient_ID","Sample_ID","Replicate")]

#Output the cleaned data
write.csv(rc, file="cleaned_data/RC_Gene_Expression.csv")
write.csv(rc_details, file="cleaned_data/RC_Metadata.csv")

acc_plot =ggplot(accuracy_df_knn, aes(x = Train_Valid, y = Accuracy, colour=GraphFeatureSetLabel)) +
  geom_violin(width=1, color=rgb(1,1,1)) +
  scale_color_manual(values=c("#fa325a", "#72def2", "#c9c9c9"),breaks = c("Top 10% Variance", "Bottom 10% Variance","Random")) +
  labs(color = "Feature Set") +
  geom_jitter(shape=16, position=position_jitter(0.1), alpha=0.65) +
  ggtitle("Accuracy of KNN Models") +
  theme(plot.title = element_text(hjust = 0.5)) +
  xlab("Training-Validation Set") + 
  scale_x_discrete(breaks=c("Doppel_0","Doppel_2", "Doppel_4", "Doppel_6", "Doppel_8", "Neg_Con", "Pos_Con"),
                   labels=c("0 Doppel", "2 Doppel", "4 Doppel", "6 Doppel", "8 Doppel", "0 Doppel\n Flipped\n Labels", "Perfect Leakage"))


accuracy_df_knn$Accuracy = as.numeric(accuracy_df_knn$Accuracy)
ggplot(accuracy_df_knn, aes(x = Train_Valid, y = Accuracy,color=ifelse(FeatureSet=="top10variance", "Top 10% Variance", ifelse(FeatureSet=="bot10variance", "Bottom 10% Variance", "Random")))) +
  geom_violin(width=1, color=rgb(1,1,1)) +
  scale_color_manual(values=c("#fa325a", "#72def2", "#c9c9c9"),breaks = c("Top 10% Variance", "Bottom 10% Variance","Random")) +
  labs(color = "Feature Set") +
  geom_jitter(shape=16, position=position_jitter(0.1), alpha=0.65) +
  ggtitle("Accuracy of KNN Models") +
  theme(plot.title = element_text(hjust = 0.5)) +
  xlab("Training-Validation Set") + 
  scale_x_discrete(breaks=c("Doppel_0","Doppel_2", "Doppel_4", "Doppel_6", "Doppel_8", "Neg_Con", "Pos_Con"),
                  labels=c("0 Doppel", "2 Doppel", "4 Doppel", "6 Doppel", "8 Doppel", "0 Doppel\n Flipped\n Labels", "Perfect Leakage"))

