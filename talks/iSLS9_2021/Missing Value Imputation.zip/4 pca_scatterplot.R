#INSTRUCTION:
#Need to run genomics_sims.R first to save the respective data in the workspace

library(ggplot2)
library(ggfortify)

dim(dat)

batch <- as.factor(c(rep(0, 32), rep(1, 32)))#for gds4056/4057 data


################ PCA SCATTERPLOTS ########################################

#batch--------------------------------------------------------
test_dat<-dat#original data with batch effects

data <- data.frame(t(test_dat), batch)#row=samples, column=proteins/genes
dim(data)
data[,dim(data)[2]]#last col with batch factors
df<-data[,-dim(data)[2]]#remove the last col with batch factors
dim(df)
pca<-prcomp(df, scale = TRUE)
pca


b<-autoplot(pca, data=data, colour="batch")+ggtitle("batch")


df.x <- as.data.frame(pca$x)
df.x$groups<-batch
df.x
dim(df.x)
df.x[,-dim(df.x)[2]]
pca.centroids <- aggregate(df.x[,-dim(df.x)[2]], list(Type=df.x$groups), mean)

dist1<-dist(rbind(pca.centroids[pca.centroids$Type == 0,2:3],pca.centroids[pca.centroids$Type == 1,2:3]), method = "euclidean")

#batch corrected----------------------------------------------------
test_dat<-dat_batch_corrected#original data with batch effects corrected

data <- data.frame(t(test_dat), batch)#row=samples, column=proteins/genes
dim(data)
df<-data[,-dim(data)[2]]#remove the last col with batch factors
dim(df)
pca<-prcomp(df, scale = TRUE)
pca


b_c<-autoplot(pca, data=data, colour="batch")+ggtitle("batch corrected")


df.x <- as.data.frame(pca$x)
df.x$groups<-batch
df.x
dim(df.x)
df.x[,-dim(df.x)[2]]
pca.centroids <- aggregate(df.x[,-dim(df.x)[2]], list(Type=df.x$groups), mean)

dist2<-dist(rbind(pca.centroids[pca.centroids$Type == 0,2:3],pca.centroids[pca.centroids$Type == 1,2:3]), method = "euclidean")

#m1 batch----------------------------------------------------
test_dat<-m_1_mat#m1 imputed data

data <- data.frame(t(test_dat), batch)#row=samples, column=proteins/genes
dim(data)
df<-data[,-dim(data)[2]]#remove the last col with batch factors
dim(df)
pca<-prcomp(df, scale = TRUE)
pca


b_m1<-autoplot(pca, data=data, colour="batch")+ggtitle("m1 batch")


df.x <- as.data.frame(pca$x)
df.x$groups<-batch
df.x
dim(df.x)
df.x[,-dim(df.x)[2]]
pca.centroids <- aggregate(df.x[,-dim(df.x)[2]], list(Type=df.x$groups), mean)

dist3<-dist(rbind(pca.centroids[pca.centroids$Type == 0,2:3],pca.centroids[pca.centroids$Type == 1,2:3]), method = "euclidean")

#m1 batch corrected----------------------------------------------------
test_dat<-m1_batch_corrected#m1 imputed data with batch effects corrected

data <- data.frame(t(test_dat), batch)#row=samples, column=proteins/genes
dim(data)
df<-data[,-dim(data)[2]]#remove the last col with batch factors
dim(df)
pca<-prcomp(df, scale = TRUE)
pca


b_m1_c<-autoplot(pca, data=data, colour="batch")+ggtitle("m1 batch corrected")


df.x <- as.data.frame(pca$x)
df.x$groups<-batch
df.x
dim(df.x)
df.x[,-dim(df.x)[2]]
pca.centroids <- aggregate(df.x[,-dim(df.x)[2]], list(Type=df.x$groups), mean)

dist4<-dist(rbind(pca.centroids[pca.centroids$Type == 0,2:3],pca.centroids[pca.centroids$Type == 1,2:3]), method = "euclidean")

#m2 batch----------------------------------------------------
test_dat<-m_2_mat#m2 imputed data

data <- data.frame(t(test_dat), batch)#row=samples, column=proteins/genes
dim(data)
df<-data[,-dim(data)[2]]#remove the last col with batch factors
dim(df)
pca<-prcomp(df, scale = TRUE)
pca


b_m2<-autoplot(pca, data=data, colour="batch")+ggtitle("m2 batch")


df.x <- as.data.frame(pca$x)
df.x$groups<-batch
df.x
dim(df.x)
df.x[,-dim(df.x)[2]]
pca.centroids <- aggregate(df.x[,-dim(df.x)[2]], list(Type=df.x$groups), mean)

dist5<-dist(rbind(pca.centroids[pca.centroids$Type == 0,2:3],pca.centroids[pca.centroids$Type == 1,2:3]), method = "euclidean")

#m2 batch corrected----------------------------------------------------
test_dat<-m2_batch_corrected#m2 imputed data with batch corrected

data <- data.frame(t(test_dat), batch)#row=samples, column=proteins/genes
dim(data)
df<-data[,-dim(data)[2]]#remove the last col with batch factors
dim(df)
pca<-prcomp(df, scale = TRUE)
pca


b_m2_c<-autoplot(pca, data=data, colour="batch")+ggtitle("m2 batch corrected")


df.x <- as.data.frame(pca$x)
df.x$groups<-batch
df.x
dim(df.x)
df.x[,-dim(df.x)[2]]
pca.centroids <- aggregate(df.x[,-dim(df.x)[2]], list(Type=df.x$groups), mean)

dist6<-dist(rbind(pca.centroids[pca.centroids$Type == 0,2:3],pca.centroids[pca.centroids$Type == 1,2:3]), method = "euclidean")

#m3 batch----------------------------------------------------
test_dat<-m_3_mat#m3 imputed data

data <- data.frame(t(test_dat), batch)#row=samples, column=proteins/genes
dim(data)
df<-data[,-dim(data)[2]]#remove the last col with batch factors
dim(df)
pca<-prcomp(df, scale = TRUE)
pca


b_m3<-autoplot(pca, data=data, colour="batch")+ggtitle("m3 batch")


df.x <- as.data.frame(pca$x)
df.x$groups<-batch
df.x
dim(df.x)
df.x[,-dim(df.x)[2]]
pca.centroids <- aggregate(df.x[,-dim(df.x)[2]], list(Type=df.x$groups), mean)

dist7<-dist(rbind(pca.centroids[pca.centroids$Type == 0,2:3],pca.centroids[pca.centroids$Type == 1,2:3]), method = "euclidean")

#m3 batch corrected----------------------------------------------------
test_dat<-m3_batch_corrected#m3 imputed data with batch corrected

data <- data.frame(t(test_dat), batch)#row=samples, column=proteins/genes
dim(data)
df<-data[,-dim(data)[2]]#remove the last col with batch factors
dim(df)
pca<-prcomp(df, scale = TRUE)
pca


b_m3_c<-autoplot(pca, data=data, colour="batch")+ggtitle("m3 batch corrected")


df.x <- as.data.frame(pca$x)
df.x$groups<-batch
df.x
dim(df.x)
df.x[,-dim(df.x)[2]]
pca.centroids <- aggregate(df.x[,-dim(df.x)[2]], list(Type=df.x$groups), mean)

dist8<-dist(rbind(pca.centroids[pca.centroids$Type == 0,2:3],pca.centroids[pca.centroids$Type == 1,2:3]), method = "euclidean")

#plots------------------------------------------
b
b_c
b_m1
b_m1_c
b_m2
b_m2_c
b_m3
b_m3_c



#distance between centriods---------------------------------
distance<-c(dist1,dist2,dist3,dist4,dist5,dist6,dist7,dist8)
labels<-c("batch", "batch corrected", 
               "m1 batch", "m1 batch corrected",
               "m2 batch", "m2 batch corrected", 
               "m3 batch", "m3 batch corrected")
options(scipen=999)
data.frame(labels, distance)



################## sample boxplots #################################
lab<-colnames(dat)

batch_sample_bp <- ggplot(data=stack(as.data.frame(dat)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("batch") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))
batch_sample_bp

batch_corrected_sample_bp <- ggplot(data=stack(as.data.frame(dat_batch_corrected)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("batch corrected") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))
batch_corrected_sample_bp

m1_batch_sample_bp <- ggplot(data=stack(as.data.frame(m_1_mat)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("m1 batch") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))
m1_batch_sample_bp

m1_batch_corrected_sample_bp <- ggplot(data=stack(as.data.frame(m1_batch_corrected)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("m1 batch corrected") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))
m1_batch_corrected_sample_bp 

m2_batch_sample_bp <- ggplot(data=stack(as.data.frame(m_2_mat)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("m2 batch") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))
m2_batch_sample_bp 

m2_batch_corrected_sample_bp <- ggplot(data=stack(as.data.frame(m2_batch_corrected)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("m2 batch corrected") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))
m2_batch_corrected_sample_bp

m3_batch_sample_bp <- ggplot(data=stack(as.data.frame(m_3_mat)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("m3 batch") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))
m3_batch_sample_bp

m3_batch_corrected_sample_bp <- ggplot(data=stack(as.data.frame(m3_batch_corrected)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("m3 batch corrected") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))
m3_batch_corrected_sample_bp 

#plots-------------------------------------------------
batch_sample_bp
batch_corrected_sample_bp
m1_batch_sample_bp
m1_batch_corrected_sample_bp 
m2_batch_sample_bp 
m2_batch_corrected_sample_bp
m3_batch_sample_bp
m3_batch_corrected_sample_bp 

dev.off()



############## IQR ###########################################

main_title="Global Additive + Multiplicative"

#ch=3 for Q3
#ch=2 for Q2
#ch=1 for Q1

##batch 0
b=0

#Q3
ch=3
q3_0<-c(quantile(dat[,which(batch==b)])[ch+1], quantile(dat_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_1_mat[,which(batch==b)])[ch+1], quantile(m1_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_2_mat[,which(batch==b)])[ch+1], quantile(m2_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_3_mat[,which(batch==b)])[ch+1], quantile(m3_batch_corrected[,which(batch==b)])[ch+1])
#Q2
ch=2
q2_0<-c(quantile(dat[,which(batch==b)])[ch+1], quantile(dat_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_1_mat[,which(batch==b)])[ch+1], quantile(m1_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_2_mat[,which(batch==b)])[ch+1], quantile(m2_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_3_mat[,which(batch==b)])[ch+1], quantile(m3_batch_corrected[,which(batch==b)])[ch+1])
#Q1
ch=1
q1_0<-c(quantile(dat[,which(batch==b)])[ch+1], quantile(dat_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_1_mat[,which(batch==b)])[ch+1], quantile(m1_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_2_mat[,which(batch==b)])[ch+1], quantile(m2_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_3_mat[,which(batch==b)])[ch+1], quantile(m3_batch_corrected[,which(batch==b)])[ch+1])

##batch 1
b=1

#Q3
ch=3
q3_1<-c(quantile(dat[,which(batch==b)])[ch+1], quantile(dat_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_1_mat[,which(batch==b)])[ch+1], quantile(m1_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_2_mat[,which(batch==b)])[ch+1], quantile(m2_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_3_mat[,which(batch==b)])[ch+1], quantile(m3_batch_corrected[,which(batch==b)])[ch+1])
#Q2
ch=2
q2_1<-c(quantile(dat[,which(batch==b)])[ch+1], quantile(dat_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_1_mat[,which(batch==b)])[ch+1], quantile(m1_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_2_mat[,which(batch==b)])[ch+1], quantile(m2_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_3_mat[,which(batch==b)])[ch+1], quantile(m3_batch_corrected[,which(batch==b)])[ch+1])
#Q1
ch=1
q1_1<-c(quantile(dat[,which(batch==b)])[ch+1], quantile(dat_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_1_mat[,which(batch==b)])[ch+1], quantile(m1_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_2_mat[,which(batch==b)])[ch+1], quantile(m2_batch_corrected[,which(batch==b)])[ch+1],
        quantile(m_3_mat[,which(batch==b)])[ch+1], quantile(m3_batch_corrected[,which(batch==b)])[ch+1])




##print raw data:-----------------------------------------------------------------------------

t_lab<-c("b", "b_c", "m1_b", "m1_b_c", "m2_b", "m2_b_c","m3_b", "m3_b_c")
b0_iqr<-rbind(q3_0,q1_0,q3_0-q1_0)
colnames(b0_iqr)<-t_lab
rownames(b0_iqr)<- c("batch 0 Q3","batch 0 Q1","batch 0 IQR")
b0_iqr

b1_iqr<-rbind(q3_1,q1_1,q3_1-q1_1)
colnames(b1_iqr)<-t_lab
rownames(b1_iqr)<- c("batch 1 Q3","batch 1 Q1","batch 1 IQR")
b1_iqr






##plot IQR weights-------------------------------------------------------

Q   <- length(q3_0)

# create a dataset
data <-rep(labels, times=2)
Batch <- rep(c("Batch 0" , "Batch 1") , each=Q)
IQR <- c(q3_0-q1_0, q3_1-q1_1)
df <- data.frame(data, Batch, IQR)

IQR_2dp <-format(round(IQR,2), nsmall = 2)#round(IQR,2)
# Grouped
ggplot(df, aes(fill=Batch, y=IQR, x=data)) + 
  geom_bar(stat="identity", position = "dodge", width=0.85) +
  geom_text(aes(label=IQR_2dp), vjust=1.6, color="white",position = position_dodge(0.85), size=2.8, fontface=2)+
  ggtitle(main_title) + ylab("IQR") + xlab("data")+
  scale_x_discrete(labels= labels)+theme(axis.text.x=element_text(color = colors, size=10, angle=30, vjust=.8, hjust=0.8))
  














