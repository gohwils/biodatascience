#INSTRUCTION:
#on line 210, please change to the directory of the file :4056_4057_ER+.csv

#ALL THE LIBRARIES FOR TEST SIMULATIONS:

library(swamp)#combat
library('gPCA')#gpca
library('bapred')#BMC-Performs batch effect adjustment by centering the variables within batches to have zero mean.
library(Harman)#harman
library('sva')#SVA
library(bladderbatch)#SVA
library(ggplot2)
library(grid)
library(gridExtra)






###################################### impute function type 4 ##############################################
impute_type_v4 <- function(test_vector, batch_factor, drop, env, D)#drop=no of datapts to drop/simulate data holes
{
  set.seed(D)
  output_list <- list()#create empty list
  temp_vector <- test_vector#create temp vector with original data
  
  drop_vector = sample(1:length(test_vector), round(length(test_vector) * drop)) #random sample index 
  env$drop<-drop_vector#pass an environment to the function and assign drop_vector to it
  
  temp_vector[(drop_vector)] <- mean(test_vector[- drop_vector])#replace values in indexes of drop vector with mean of remaining values of test vector
  
  output_list[[1]] <- temp_vector#save temp_vector with imputed grand mean values in output list
  
  temp_vector <- test_vector #reset temp_vector so that it contains original data
  
  reduced_temp_vector <- temp_vector#reduced_temp_vector contains original data
  reduced_batch_vector <- batch_factor#reduced_batch_vector contains the batches
  reduced_temp_vector <- reduced_temp_vector[!(1:length(reduced_temp_vector) %in% drop_vector)]#remaining values that are not missing assigned to reduced_temp_vector
  reduced_batch_vector <- reduced_batch_vector[!(1:length(reduced_batch_vector) %in% drop_vector)]#corresponding batches of the remaining values that are not missing  
  
  global_mean <- mean(reduced_temp_vector)#mean of the remaining values
  b1_mean <- mean(reduced_temp_vector[reduced_batch_vector == 0])#mean of the remaining values that are in batch 0
  b2_mean <- mean(reduced_temp_vector[reduced_batch_vector == 1])#mean of the remaining values that are in batch 1
  
  if (is.na(b1_mean))#batch may be empty due to random dropping
  {
    b1_mean <- global_mean
  }
  if (is.na(b2_mean))
  {
    b2_mean <- global_mean
  } 
  
  
  #start for m2 here
  temp_vector[(drop_vector)] = 0 #drop all the missing values (missing values from temp vector becomes 0)
  clone_factor <- batch_factor
  levels(clone_factor) <- c(b1_mean, b2_mean) #reverse here for m3
  clone_factor <- as.numeric(as.vector(clone_factor))#vector containing corresponding same batch means
  
  
  clone_factor[!(1:length(test_vector) %in% drop_vector)] = 0#values that are not missing replaced with 0s
  m2_output <- temp_vector + clone_factor#m2_output=original data+ same batch mean imputed for missing data
  output_list[[2]] <- m2_output
  
  #start for m3 here
  clone_factor <- batch_factor
  levels(clone_factor) <- c(b2_mean, b1_mean) #reverse here for m3
  clone_factor <- as.numeric(as.vector(clone_factor))
  clone_factor[!(1:length(test_vector) %in% drop_vector)] = 0
  
  m3_output <- temp_vector + clone_factor
  output_list[[3]] <- m3_output
  
  #final output here
  #output_list[[4]]<-drop_vector
  
  #start for missing data here
  temp_vector <- test_vector #reset temp_vector so that it contains original data
  temp_vector[(drop_vector)] <- NA#replace values in indexes of drop vector with NA
  output_list[[4]]<-temp_vector
  
  return(output_list)
}
######################################## RMSE FUNCTION #####################################################
rmse<-function(dat_null, null_batch_corrected, dat, dat_batch_corrected, m_1_mat, m1_batch_corrected, m_2_mat, m2_batch_corrected, m_3_mat, m3_batch_corrected)
{
  rmse_batch <- sum((dat - dat_null)^2)/(nrow(dat)*ncol(dat))
  rmse_batch_corrected <- sum((dat_batch_corrected - null_batch_corrected)^2)/(nrow(dat)*ncol(dat))
  
  #calculate RMSE for m_1_mat,m_2_mat,m_3_mat (with missing values imputed but NOT CORRECTED FOR BATCH EFFECT) 
  #against original data
  rmse_batch_m1 <- sum((m_1_mat - dat_null)^2)/(nrow(dat)*ncol(dat))
  rmse_batch_m2 <- sum((m_2_mat - dat_null)^2)/(nrow(dat)*ncol(dat))
  rmse_batch_m3 <- sum((m_3_mat - dat_null)^2)/(nrow(dat)*ncol(dat))
  
  
  #calculate RMSE for m1_batch_corrected,m2_batch_corrected,m3_batch_corrected (with missing values imputed but CORRECTED FOR BATCH EFFECT) 
  #against original data
  rmse_batch_corrected_m1 <- sum((m1_batch_corrected - null_batch_corrected)^2)/(nrow(dat)*ncol(dat))
  rmse_batch_corrected_m2 <- sum((m2_batch_corrected - null_batch_corrected)^2)/(nrow(dat)*ncol(dat))
  rmse_batch_corrected_m3 <- sum((m3_batch_corrected - null_batch_corrected)^2)/(nrow(dat)*ncol(dat))
  
  #}
  
  #sqrt!!!!!!!!!!
  rmse_batch=sqrt(rmse_batch)
  rmse_batch_corrected=sqrt(rmse_batch_corrected)
  rmse_batch_m1=sqrt(rmse_batch_m1)
  rmse_batch_corrected_m1=sqrt(rmse_batch_corrected_m1)
  rmse_batch_m2=sqrt(rmse_batch_m2)
  rmse_batch_corrected_m2=sqrt(rmse_batch_corrected_m2)
  rmse_batch_m3=sqrt(rmse_batch_m3)
  rmse_batch_corrected_m3=sqrt(rmse_batch_corrected_m3)
  
  rmse_vec<-c(rmse_batch, rmse_batch_corrected,
              rmse_batch_m1, rmse_batch_corrected_m1,
              rmse_batch_m2, rmse_batch_corrected_m2, 
              rmse_batch_m3, rmse_batch_corrected_m3)
  return(rmse_vec)
}

########################################### GPCA DELTA FUNCTION ###########################################
#input data matrices: where row=no of observation (which is where batch effects occurs), col=no of features
gpca_delta<-function(dat_null, dat, dat_batch_corrected, m_1_mat, m1_batch_corrected, m_2_mat, m2_batch_corrected, m_3_mat, m3_batch_corrected)
{
  #true null***
  out_null<-gPCA.batchdetect(x=t(dat_null), batch=batch_factor, center=FALSE)
  delta_null<-out_null$delta
  
  #gPCA after batch correction
  out_batch_corrected<-gPCA.batchdetect(x=t(dat_batch_corrected), batch=batch_factor, center=FALSE)
  delta_batch_corrected<-out_batch_corrected$delta
  
  #calculate gPCA delta for m1_batch_corrected,m2_batch_corrected,m3_batch_corrected (with missing values imputed but CORRECTED FOR BATCH EFFECT) 
  out_batch_corrected_m1<-gPCA.batchdetect(x=t(m1_batch_corrected),batch=batch_factor,center=FALSE)
  delta_batch_corrected_m1<-out_batch_corrected_m1$delta
  
  out_batch_corrected_m2<-gPCA.batchdetect(x=t(m2_batch_corrected ),batch=batch_factor,center=FALSE)
  delta_batch_corrected_m2<-out_batch_corrected_m2$delta
  
  out_batch_corrected_m3<-gPCA.batchdetect(x=t(m3_batch_corrected ),batch=batch_factor,center=FALSE)
  delta_batch_corrected_m3<-out_batch_corrected_m3$delta
  
  #}
  #gPCA before batch correction
  out_batch<-gPCA.batchdetect(x=t(dat),batch=batch_factor,center=FALSE)#data matrix x: where row=no of observation (which is where batch effects occurs), col=no of features
  delta_batch<-out_batch$delta
  
  #calculate gPCA delta for m_1_mat,m_2_mat,m_3_mat (with missing values imputed but NOT CORRECTED FOR BATCH EFFECT) 
  out_batch_m1<-gPCA.batchdetect(x=t(m_1_mat),batch=batch_factor,center=FALSE)
  delta_batch_m1<-out_batch_m1$delta
  
  out_batch_m2<-gPCA.batchdetect(x=t(m_2_mat),batch=batch_factor,center=FALSE)
  delta_batch_m2<-out_batch_m2$delta
  
  out_batch_m3<-gPCA.batchdetect(x=t(m_3_mat),batch=batch_factor,center=FALSE)
  delta_batch_m3<-out_batch_m3$delta
  
  
  
  delta_vec<-c(delta_null, delta_batch, delta_batch_corrected, 
               delta_batch_m1, delta_batch_corrected_m1, 
               delta_batch_m2, delta_batch_corrected_m2,
               delta_batch_m3, delta_batch_corrected_m3)
  
  return(delta_vec)
  
}

############################################# batch effects ################################################
batch_effect<-function(test_mat, multiplicative=FALSE, additive=FALSE)
{
  n=ncol(test_mat)
  n2=n/2
  n3=n2+1
  if(multiplicative==TRUE && additive==FALSE){
    test_mat_batch <- cbind(test_mat[,1:n2]*Z, test_mat[,n3:n])#create batch effect(first 10 cols vs last 10 cols)
  } else if (multiplicative==FALSE && additive==TRUE){
    test_mat_batch <- cbind(test_mat[,1:n2]+Y, test_mat[,n3:n])#Maybe we can calculate global average, take the square root and then add
  } else if (multiplicative==TRUE && additive==TRUE){
    test_mat_batch <- cbind(Z*(test_mat[,1:n2]+Y), test_mat[,n3:n])#Z(X+Y), where y is the additive factor, and z is the multiplicative factor.
  } else{
    test_mat_batch<-test_mat
  }
  return(test_mat_batch)
  
}


###################################### GENOMICS DATA #########################################################
#32 samples in batch 4056, 32 samples in batch 4057 
#with one true sample class: ER +

##gds4056/4057
dat<-read.csv("C:/Users/psyq9/OneDrive/Desktop/FYP/PROTEOMICS/4056_4057_ER+.csv")


dim(dat)

row_names<-dat[,1]
dat<-dat[,-1]#drop id column
rownames(dat)<-row_names

dim(dat)#(22283    64)



sum(is.na(dat))#No NA
dat<-as.matrix(dat)

#plot
## plot density##
title="Distribution of GDS4056/4057 Data"
plot(density(dat), main=title)

##gds4056/4057
data_title="GDS4056/4057"



lab<-colnames(dat)
ggplot(data=stack(as.data.frame(dat)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle(data_title) + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))


#z-transform data: mean=0; sd=1
#scale is generic function whose default method centers and/or scales the columns of a numeric matrix.
dat<-scale(dat, center=TRUE, scale=TRUE)
dim(dat)

#plot
lab<-colnames(dat)
ggplot(data=stack(as.data.frame(dat)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("z-transformed data") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))


#add 5 to every data to force genomics data to be close to simulation,mean=5
dat<-dat+5

## plot density##
title="Distribution of Processed GDS4056/4057 Data"
plot(density(dat), main=title)
#abline(v = mean(dat), col="red", lwd=3, lty=2)

#plot
lab<-colnames(dat)
ggplot(data=stack(as.data.frame(dat)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("z-transformed data + 5") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))



##amplify batch effects of first 32 cols
Z=1.2#multiplicative batch factor
Y=sqrt(5)#additive batch factor

dat_null<-dat
#dat_null is the original data without amplification of batch effects a.k.a true null

dat<-batch_effect(dat, multiplicative=TRUE, additive=TRUE)#-----change dat to dat_class if class effects turn on

#plot
lab<-colnames(dat)
ggplot(data=stack(as.data.frame(dat)), aes(x = ind, y = values)) + 
  geom_boxplot() + ggtitle("data with batch") + ylab("values") + xlab("samples")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(size=8, angle=90, vjust=.8, hjust=0.8))











############################################## Testing #######################################################

#change parameters here!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

scale =5
drop = 0.5
batch_factor <- as.factor(c(rep(0, 32), rep(1, 32)))





#define output vectors
RMSE_output <- matrix(rep(0, 8))#6 rows of 0; 1 column
delta_output <- matrix(rep(0, 9))#8 rows


#check
DROP_VECTORS<-list()#save all drop_vectors(for all rows) for dat in a list


start_time <- Sys.time()






#M1,M2,M3------------------------------------------------------------------------
D=0#counter for number of drop vectors generated. By the end of the loop, D should be 20*N

#test_list <- apply(dat, 1, impute_type_v2)
m_1_mat <- matrix(rep(0, nrow(dat) * ncol(dat)), nrow= nrow(dat))#20x20 matrix of zeroes
m_2_mat <- matrix(rep(0, nrow(dat) * ncol(dat)), nrow= nrow(dat))
m_3_mat <- matrix(rep(0, nrow(dat) * ncol(dat)), nrow= nrow(dat))
m_4_mat <- matrix(rep(0, nrow(dat) * ncol(dat)), nrow= nrow(dat))


for (j in 1:nrow(dat))#for EACH ROW in dat, randomly drop=0.5 of the values and impute via M1,M2,M3
{
  D=D+1
  myEnv <- new.env()
  test_list <- impute_type_v4(dat[j,], batch_factor, drop, myEnv, D)
  DROP_VECTORS[[j]]<-myEnv$drop#add drop_vector of each row to list
  #DROP_VECTORS[[j]]<- test_list[[4]]
  
  m_1_mat[j,] = test_list[[1]]#row i imputed by grand mean (M1) replace row i in m_1_mat
  m_2_mat[j,] = test_list[[2]]#row i imputed by same batch mean (M2) replace row i in m_2_mat
  m_3_mat[j,] = test_list[[3]]#row i imputed by opposite batch mean (M3) replace row i in m_3_mat
  m_4_mat[j,] = test_list[[4]]#missing values not imputed
}#repeat until all rows of m_1_mat,m_2_mat,m_3_mat are replaced by M1, M2, M3 imputed rows respectively




#COMBAT---------------------------------------------------------------------------------

null_batch_corrected <- combat(dat_null, batch_factor, batchcolumn = 1)#true null batch corrected



dat_batch_corrected <- combat(dat, batch_factor, batchcolumn = 1)#batch effect correction via COMBAT (swamp)
#the input data in form of a matrix with features as rows and samples as columns.

#apply batch correction COMBAT for m_1_mat,m_2_mat,m_3_mat with missing values imputed
par=TRUE
m1_batch_corrected <- combat(m_1_mat, batch_factor, batchcolumn = 1, par.prior=par)
m2_batch_corrected <- combat(m_2_mat, batch_factor, batchcolumn = 1, par.prior=par)
m3_batch_corrected <- combat(m_3_mat, batch_factor, batchcolumn = 1, par.prior=par)

#get rows with NAs
unique(which(is.na(m1_batch_corrected), arr.ind=TRUE)[,1])#0 rows with NAs
unique(which(is.na(m2_batch_corrected), arr.ind=TRUE)[,1])#get rows with NAs
unique(which(is.na(m3_batch_corrected), arr.ind=TRUE)[,1])#0 rows with NAs





#RMSE
rmse_vec<-rmse(dat_null, null_batch_corrected, dat, dat_batch_corrected, m_1_mat, m1_batch_corrected, m_2_mat, m2_batch_corrected, m_3_mat, m3_batch_corrected)

#gpca delta
delta_vec<-gpca_delta(dat_null, dat, dat_batch_corrected, m_1_mat, m1_batch_corrected, m_2_mat, m2_batch_corrected, m_3_mat, m3_batch_corrected)

delta_output <- cbind(delta_output, delta_vec)
RMSE_output <- cbind(RMSE_output, rmse_vec)

end_time <- Sys.time()
end_time - start_time#Time difference of 9.087292 mins















########################################plot################################################################
library(ggplot2)
##delete column 1 with all the zeroes

dim(delta_output)
delta_output <- delta_output[,-1]
dim(delta_output)

dim(RMSE_output)
RMSE_output <- RMSE_output[,-1]
dim(RMSE_output)


#labels
lab<-c("batch", "batch corrected", 
       "m1 batch", "m1 batch corrected",
       "m2 batch", "m2 batch corrected", 
       "m3 batch", "m3 batch corrected")
colors = c(rep("black",2),rep("maroon",2),rep("dark green",2),rep("dark blue",2))

#gpca delta labels
glab<-c("true null", "batch", "batch corrected", 
        "m1 batch", "m1 batch corrected",
        "m2 batch", "m2 batch corrected", 
        "m3 batch", "m3 batch corrected")
gcolors = c("grey36", rep("black",2),rep("maroon",2),rep("dark green",2),rep("dark blue",2))

#combat--------------------------------------------------------------------------------
main_title="ComBat - Global Additive + Multiplicative"#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
##RMSE
RMSE_output<-as.data.frame(RMSE_output)
write.table(RMSE_output, file="testout.txt", quote=F, sep="\t")

#ggplot
rmse_bp <-ggplot(data=stack(as.data.frame(t(RMSE_output))), aes(x = ind, y = values,))+
  geom_boxplot(color=colors) + ggtitle(main_title) + ylab("RMSE") + xlab("data")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(color = colors, size=10, angle=30, vjust=.8, hjust=0.8))
rmse_bp
#basic boxplot
boxplot(t(RMSE_output))



##gPCA
delta_output<-as.data.frame(delta_output)
write.table(delta_output, file="testout.txt", quote=F, sep="\t")

#ggplot
delta_bp<-ggplot(data=stack(as.data.frame(t(delta_output))), aes(x = ind, y = values,))+
  geom_boxplot(color=gcolors) + ggtitle(main_title) + ylab("gPCA delta") + xlab("data")+
  scale_x_discrete(labels= glab)+theme(axis.text.x=element_text(color = gcolors, size=10, angle=30, vjust=.8, hjust=0.8))
delta_bp
#basic boxplot
boxplot(t(delta_output))





