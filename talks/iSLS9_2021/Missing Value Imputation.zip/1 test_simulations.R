#All the Libraries:
library(swamp)#combat
library('gPCA')#gpca
library('bapred')#BMC-Performs batch effect adjustment by centering the variables within batches to have zero mean.
library(Harman)#harman
library('sva')#SVA
library(bladderbatch)#SVA
library(ggplot2)
library(grid)
library(gridExtra)

# install.packages("BiocManager")
# library("BiocManager")
# BiocManager::install("genefilter")
# 
# install.packages("XML", type = "binary")


################### impute function type 4 #########################
impute_type_v4 <- function(test_vector, batch_factor, drop, env, D)#drop=no of datapoints to drop/simulate data holes
{
  set.seed(D)
  output_list <- list()#create empty list
  temp_vector <- test_vector#create temp vector with original data
 
  drop_vector = sample(1:length(test_vector), round(length(test_vector) * drop)) #random sample index 
  env$drop<-drop_vector#pass an environment to the function and assign drop_vector to it
  
  temp_vector[(drop_vector)] <- mean(test_vector[- drop_vector])#replace values in indexes of drop vector with mean of remaining values of test vector
  
  output_list[[1]] <- temp_vector#save temp_vector with imputed grand mean values in output list
  
  temp_vector <- test_vector #reset temp_vector so that it contains original data
  
  reduced_temp_vector <- temp_vector#reduced_temp_vector contains original data
  reduced_batch_vector <- batch_factor#reduced_batch_vector contains the batches
  reduced_temp_vector <- reduced_temp_vector[!(1:length(reduced_temp_vector) %in% drop_vector)]#remaining values that are not missing assigned to reduced_temp_vector
  reduced_batch_vector <- reduced_batch_vector[!(1:length(reduced_batch_vector) %in% drop_vector)]#corresponding batches of the remaining values that are not missing  
  
  global_mean <- mean(reduced_temp_vector)#mean of the remaining values
  b1_mean <- mean(reduced_temp_vector[reduced_batch_vector == 0])#mean of the remaining values that are in batch 0
  b2_mean <- mean(reduced_temp_vector[reduced_batch_vector == 1])#mean of the remaining values that are in batch 1
  
  if (is.na(b1_mean))#batch may be empty due to random dropping
  {
    b1_mean <- global_mean
  }
  if (is.na(b2_mean))
  {
    b2_mean <- global_mean
  } 
  
  
  #start for m2 here
  temp_vector[(drop_vector)] = 0 #drop all the missing values (missing values from temp vector becomes 0)
  clone_factor <- batch_factor
  levels(clone_factor) <- c(b1_mean, b2_mean) #reverse here for m3
  clone_factor <- as.numeric(as.vector(clone_factor))#vector containing corresponding same batch means
  
  
  clone_factor[!(1:length(test_vector) %in% drop_vector)] = 0#values that are not missing replaced with 0s
  m2_output <- temp_vector + clone_factor#m2_output=original data+ same batch mean imputed for missing data
  output_list[[2]] <- m2_output
  
  #start for m3 here
  clone_factor <- batch_factor
  levels(clone_factor) <- c(b2_mean, b1_mean) #reverse here for m3
  clone_factor <- as.numeric(as.vector(clone_factor))
  clone_factor[!(1:length(test_vector) %in% drop_vector)] = 0
  
  m3_output <- temp_vector + clone_factor
  output_list[[3]] <- m3_output
  
  #start for missing data here
  temp_vector <- test_vector #reset temp_vector so that it contains original data
  temp_vector[(drop_vector)] <- NA#replace values in indexes of drop vector with NA
  output_list[[4]]<-temp_vector
  
  #final output here
  return(output_list)
}



######################### RMSE FUNCTION ###################################
rmse<-function(test_mat, test_mat_batch, test_mat_batch_corrected, m_1_mat, m1_batch_corrected, m_2_mat, m2_batch_corrected, m_3_mat, m3_batch_corrected, test_mat_corrected)
{
  
  #RMSE
  rmse_batch <- sum((test_mat_batch - test_mat)^2)/(nrow(test_mat)*ncol(test_mat))#root mean square error (RMSE)
  
  
  
  #calculate RMSE for m_1_mat,m_2_mat,m_3_mat (with missing values imputed but NOT CORRECTED FOR BATCH EFFECT) 
  #against original data
  rmse_batch_m1 <- sum((m_1_mat - test_mat)^2)/(nrow(test_mat)*ncol(test_mat))
  rmse_batch_m2 <- sum((m_2_mat - test_mat)^2)/(nrow(test_mat)*ncol(test_mat))
  rmse_batch_m3 <- sum((m_3_mat - test_mat)^2)/(nrow(test_mat)*ncol(test_mat))
  

  rmse_batch_corrected <- sum((test_mat_batch_corrected - test_mat_corrected)^2)/(nrow(test_mat)*ncol(test_mat))#RMSE of corrected test_mat_batch
  
  
  #calculate RMSE for m1_batch_corrected,m2_batch_corrected,m3_batch_corrected (with missing values imputed but CORRECTED FOR BATCH EFFECT) 
  #against original data
  rmse_batch_corrected_m1 <- sum((m1_batch_corrected - test_mat_corrected)^2)/(nrow(test_mat)*ncol(test_mat))
  rmse_batch_corrected_m2 <- sum((m2_batch_corrected - test_mat_corrected)^2)/(nrow(test_mat)*ncol(test_mat))
  rmse_batch_corrected_m3 <- sum((m3_batch_corrected - test_mat_corrected)^2)/(nrow(test_mat)*ncol(test_mat))
  
  #sqrt!!!!!!!!!!
  rmse_batch=sqrt(rmse_batch)
  rmse_batch_corrected=sqrt(rmse_batch_corrected)
  rmse_batch_m1=sqrt(rmse_batch_m1)
  rmse_batch_corrected_m1=sqrt(rmse_batch_corrected_m1)
  rmse_batch_m2=sqrt(rmse_batch_m2)
  rmse_batch_corrected_m2=sqrt(rmse_batch_corrected_m2)
  rmse_batch_m3=sqrt(rmse_batch_m3)
  rmse_batch_corrected_m3=sqrt(rmse_batch_corrected_m3)
  
  
  rmse_vec<-c(rmse_batch, rmse_batch_corrected, 
                rmse_batch_m1, rmse_batch_corrected_m1,
                rmse_batch_m2, rmse_batch_corrected_m2, 
                rmse_batch_m3, rmse_batch_corrected_m3)
  return(rmse_vec)
}

################### GPCA DELTA FUNCTION ######################
#input data matrices: where row=no of observation (which is where batch effects occurs), col=no of features
gpca_delta<-function(test_mat, test_mat_batch, test_mat_batch_corrected, m_1_mat, m1_batch_corrected, m_2_mat, m2_batch_corrected, m_3_mat, m3_batch_corrected)
{
  
  #gPCA after batch correction
  out_batch_corrected<-gPCA.batchdetect(x=t(test_mat_batch_corrected), batch=batch_factor, center=FALSE)
  delta_batch_corrected<-out_batch_corrected$delta
  
  #calculate gPCA delta for m1_batch_corrected,m2_batch_corrected,m3_batch_corrected (with missing values imputed but CORRECTED FOR BATCH EFFECT) 
  out_batch_corrected_m1<-gPCA.batchdetect(x=t(m1_batch_corrected),batch=batch_factor,center=FALSE)
  delta_batch_corrected_m1<-out_batch_corrected_m1$delta
  
  out_batch_corrected_m2<-gPCA.batchdetect(x=t(m2_batch_corrected ),batch=batch_factor,center=FALSE)
  delta_batch_corrected_m2<-out_batch_corrected_m2$delta
  
  out_batch_corrected_m3<-gPCA.batchdetect(x=t(m3_batch_corrected ),batch=batch_factor,center=FALSE)
  delta_batch_corrected_m3<-out_batch_corrected_m3$delta
    

  #gPCA
  out_batch<-gPCA.batchdetect(x=t(test_mat_batch),batch=batch_factor,center=FALSE)#data matrix x: where row=no of observation (which is where batch effects occurs), col=no of features
  delta_batch<-out_batch$delta
  
  #calculate gPCA delta for m_1_mat,m_2_mat,m_3_mat (with missing values imputed but NOT CORRECTED FOR BATCH EFFECT) 
  out_batch_m1<-gPCA.batchdetect(x=t(m_1_mat),batch=batch_factor,center=FALSE)
  delta_batch_m1<-out_batch_m1$delta
  
  out_batch_m2<-gPCA.batchdetect(x=t(m_2_mat),batch=batch_factor,center=FALSE)
  delta_batch_m2<-out_batch_m2$delta
  
  out_batch_m3<-gPCA.batchdetect(x=t(m_3_mat),batch=batch_factor,center=FALSE)
  delta_batch_m3<-out_batch_m3$delta
  
  #true null
  out_true_null<-gPCA.batchdetect(x=t(test_mat), batch=batch_factor, center=FALSE)
  delta_true_null<-out_true_null$delta
  
  
  delta_vec<-c(delta_true_null, delta_batch, delta_batch_corrected, 
               delta_batch_m1, delta_batch_corrected_m1, 
               delta_batch_m2, delta_batch_corrected_m2,
               delta_batch_m3, delta_batch_corrected_m3)
  
  return(delta_vec)

}

###################### SVA function ##############################
sva_function<-function(test_mat_batch)
{
  exprs<-as.matrix(test_mat_batch)#data values
  
  pData<-data.frame(group=class_factor, batch=batch_factor, row.names=colnames(test_mat_batch))
  #group=0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1
  #batch=0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1
  
  phenoData <- AnnotatedDataFrame(data=pData)
  #An object of class 'AnnotatedDataFrame'
  #rowNames: 1 2 ... 20 (20 total)
  #varLabels: group batch
  #varMetadata: labelDescription
  
  colnames(exprs) <- row.names(pData)#colnames of exprs(matrix containing data values)= 1,2,3,...,20
  
  eset <- ExpressionSet(exprs, phenoData=phenoData)
  
  pheno = pData(eset)
  #group=0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1
  #batch=0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1
  
  edata = exprs(eset)#data values
  
  mod = model.matrix(~as.factor(group), data=pheno)
  mod0 = model.matrix(~1,data=pheno)
  svobj = sva(edata,mod,mod0,n.sv=1)#number of surrogate variables (n.sv) = 1 (batch factor)
  #svobj$sv
  
  cleanY = function(y, mod, sv) {
    X = cbind(mod, sv)
    Hat = solve(t(X) %*% X) %*% t(X)# %*% is matrix multiplication
    beta = (Hat %*% t(y))
    rm(Hat)
    gc()
    P = ncol(mod)
    return(y - t(as.matrix(X[,-c(1:P)]) %*% beta[-c(1:P),]))
  }
  data<-cleanY(edata,mod,svobj$sv)
  return(data)
}

####################### batch effects #############################
batch_effect<-function(test_mat, multiplicative=FALSE, additive=FALSE)
{
  if(multiplicative==TRUE && additive==FALSE){
    test_mat_batch <- cbind(test_mat[,1:10]*1.2, test_mat[,11:20])#create batch effect(first 10 cols vs last 10 cols)
  } else if (multiplicative==FALSE && additive==TRUE){
    test_mat_batch <- cbind(test_mat[,1:10]+sqrt(5), test_mat[,11:20])#Maybe we can calculate global average, take the square root and then add
  } else if (multiplicative==TRUE && additive==TRUE){
    test_mat_batch <- cbind(1.2*(test_mat[,1:10]+sqrt(5)), test_mat[,11:20])#z(x + y), where y is the additive factor, and z is the multiplicative factor.
  } else{
    test_mat_batch<-test_mat
  }
  return(test_mat_batch)
  
}

################### class effects ############################
#simulate class effects for first 10 rows only to calculate TP, FN, TN, FP for class effects using t-stats
class_effect <- function(test_mat, halfway=FALSE)
{
  if(halfway==TRUE)
  {
    test_mat[1:10,c(which(class_factor==0))]=test_mat[1:10,c(which(class_factor==0))]*1.5
  }else{
    test_mat[,c(which(class_factor==0))]=test_mat[,c(which(class_factor==0))]*1.5
  }
  return(test_mat)
}


########################### Testing #################################


#change parameters here!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
N=10
scale =5
batch_factor <- as.factor(c(rep(0, 10), rep(1, 10)))#c(0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1) levels:0 1
class_factor <- as.factor(rep(c(0, 1), 10))#c(0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1 0 1) levels:0 1
drop = 0.5


#combat
RMSE_output <- matrix(rep(0, 8))#8 rows of 0; 1 column
delta_output <- matrix(rep(0, 9))#9 rows
#bmc
RMSE_output_bmc <- matrix(rep(0, 8))
delta_output_bmc <- matrix(rep(0, 9))
#harman
RMSE_output_harman <- matrix(rep(0, 8))
delta_output_harman<- matrix(rep(0, 9))
#SVA
RMSE_output_sva <- matrix(rep(0, 8))
delta_output_sva <- matrix(rep(0, 9))

#Save all matrices generated in lists for reference
TEST_MATS<-list()#save all test_mat (with class effects) in a list
TEST_MATS_BATCH<-list()#save all test_mat_batch in a list
DROP_VEC_ROW_MAT<-list()#save all drop_vectors(for all rows) for all test_mat_batch in a list

M_1_MATS<-list()
M_2_MATS<-list()
M_3_MATS<-list()
M_4_MATS<-list()
TEST_MATS_CORRECTED<-list()
TEST_MATS_BATCH_CORRECTED<-list()
M1_BATCH_CORRECTED<-list()
M2_BATCH_CORRECTED<-list()
M3_BATCH_CORRECTED<-list()

TEST_MATS_CORRECTED_BMC<-list()
TEST_MATS_BATCH_CORRECTED_BMC<-list()
M1_BATCH_CORRECTED_BMC<-list()
M2_BATCH_CORRECTED_BMC<-list()
M3_BATCH_CORRECTED_BMC<-list()

TEST_MATS_CORRECTED_HARMAN<-list()
TEST_MATS_BATCH_CORRECTED_HARMAN<-list()
M1_BATCH_CORRECTED_HARMAN<-list()
M2_BATCH_CORRECTED_HARMAN<-list()
M3_BATCH_CORRECTED_HARMAN<-list()

TEST_MATS_CORRECTED_SVA<-list()
TEST_MATS_BATCH_CORRECTED_SVA<-list()
M1_BATCH_CORRECTED_SVA<-list()
M2_BATCH_CORRECTED_SVA<-list()
M3_BATCH_CORRECTED_SVA<-list()

start_time <- Sys.time()
D=0#counter for number of drop vectors generated. By the end of the loop, D should be 20*N
for (i in 1:N)
{
  set.seed(i)#generate test_mat and drop_vectors that are reproducible each iteration
  
  test_mat <- matrix(rnorm(400, scale, 1), nrow=20)#rnorm generates a vector of normally distributed random numbers 
  #rnorm(n,mean,standard_dev)
  #create a matrix of 20rows, 20cols, with normally distributed random numbers of mean=5,sd=1
  
  #create class effects (alternate COLUMNS)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  test_mat<-class_effect(test_mat, halfway=FALSE)
  
  TEST_MATS[[i]]<-test_mat#save test_mat in list TEST_MATS
  
  #create batch effect(first 10 cols vs last 10 cols)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  test_mat_batch<-batch_effect(test_mat, multiplicative=TRUE, additive=TRUE)
  
  TEST_MATS_BATCH[[i]]<-test_mat_batch#save test_mat_batch in list TEST_MATS_BATCH
  
  #test_list <- apply(test_mat, 1, impute_type_v2)
  m_1_mat <- matrix(rep(0, nrow(test_mat) * ncol(test_mat)), nrow= nrow(test_mat))#20x20 matrix of zeroes
  m_2_mat <- matrix(rep(0, nrow(test_mat) * ncol(test_mat)), nrow= nrow(test_mat))
  m_3_mat <- matrix(rep(0, nrow(test_mat) * ncol(test_mat)), nrow= nrow(test_mat))
  m_4_mat <- matrix(rep(0, nrow(test_mat) * ncol(test_mat)), nrow= nrow(test_mat))
  
  DROP_VEC_ROW<-list()#Compile list of drop vectors for all rows of test_mat_batch
  for (j in 1:nrow(test_mat_batch))#for EACH ROW in test_mat_batch, randomly drop=0.5 of the values and impute via M1,M2,M3
  {
    D=D+1
    myEnv <- new.env()
    test_list <- impute_type_v4(test_mat_batch[j,], batch_factor, drop, myEnv, D)
    DROP_VEC_ROW[[j]]<-myEnv$drop#add drop_vector of each row to list
    
    m_1_mat[j,] = test_list[[1]]#row i imputed by grand mean (M1) replace row i in m_1_mat
    m_2_mat[j,] = test_list[[2]]#row i imputed by same batch mean (M2) replace row i in m_2_mat
    m_3_mat[j,] = test_list[[3]]#row i imputed by opposite batch mean (M3) replace row i in m_3_mat
    m_4_mat[j,] = test_list[[4]]#missing values not imputed
  }#repeat until all rows of m_1_mat,m_2_mat,m_3_mat are replaced by M1, M2, M3 imputed rows respectively
  
  DROP_VEC_ROW_MAT[[i]]<-DROP_VEC_ROW#add list of drop_vectors for this test_mat_batch to list
  
  M_1_MATS[[i]]<-m_1_mat
  M_2_MATS[[i]]<-m_2_mat
  M_3_MATS[[i]]<-m_3_mat
  M_4_MATS[[i]]<-m_4_mat
  
  #COMBAT---------------------------------------------------------------------------------
  test_mat_batch_corrected <- combat(test_mat_batch, batch_factor, batchcolumn = 1)#batch effect correction via COMBAT (swamp)
  #the input data in form of a matrix with features as rows and samples as columns.
  
  test_mat_corrected <- combat(test_mat, batch_factor, batchcolumn = 1)
  #run original data matrix through combat for comparison with batch corrected data as combat transform data values
  
  #apply batch correction COMBAT for m_1_mat,m_2_mat,m_3_mat with missing values imputed
  m1_batch_corrected <- combat(m_1_mat, batch_factor, batchcolumn = 1)
  m2_batch_corrected <- combat(m_2_mat, batch_factor, batchcolumn = 1)
  m3_batch_corrected <- combat(m_3_mat, batch_factor, batchcolumn = 1)
  
  
  
  #SAVE DATA
  TEST_MATS_CORRECTED[[i]]<-test_mat_corrected
  TEST_MATS_BATCH_CORRECTED[[i]]<-test_mat_batch_corrected
  M1_BATCH_CORRECTED[[i]]<-m1_batch_corrected
  M2_BATCH_CORRECTED[[i]]<-m2_batch_corrected
  M3_BATCH_CORRECTED[[i]]<-m3_batch_corrected
  
  
  
  #RMSE
  rmse_vec<-rmse(test_mat, test_mat_batch, test_mat_batch_corrected, m_1_mat, m1_batch_corrected, m_2_mat, m2_batch_corrected, m_3_mat, m3_batch_corrected, test_mat_corrected)
  
  #gpca delta
  delta_vec<-gpca_delta(test_mat, test_mat_batch, test_mat_batch_corrected, m_1_mat, m1_batch_corrected, m_2_mat, m2_batch_corrected, m_3_mat, m3_batch_corrected)
  
  delta_output <- cbind(delta_output, delta_vec)
  RMSE_output <- cbind(RMSE_output, rmse_vec)
  
  #BMC-----------------------------------------------------------------------------------
  batch_factor_bmc<- as.factor(as.numeric(batch_factor))#c(1 1 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2 2 2 2) Levels: 1 2
  
  test_mat_corrected_bmc <- meancenter(t(test_mat), batch_factor_bmc)#BMC the reference data (without batch effects) and compare to the BMC-corrected data.
  
  test_mat_batch_corrected_bmc <- meancenter(t(test_mat_batch), batch_factor_bmc)#batch effect adjustment by mean-centering
  #meancenter(x, batch)
  #x : Observations in rows, variables in columns.
  #return a list: 'Mean centering'-adjusted training data with information for addon batch effect adjustment. 
  #Number of batches: 2 
  #Number(s) of observations (within each batch): 5, 5 
  #Number of variables: 10 
  
  #apply batch correction BMC for m_1_mat,m_2_mat,m_3_mat with missing values imputed
  m1_batch_corrected_bmc <- meancenter(t(m_1_mat), batch_factor_bmc)
  m2_batch_corrected_bmc <- meancenter(t(m_2_mat), batch_factor_bmc)
  m3_batch_corrected_bmc <- meancenter(t(m_3_mat), batch_factor_bmc)
  
  
  
  #SAVE DATA
  TEST_MATS_CORRECTED_BMC[[i]]<-test_mat_corrected_bmc$xadj
  TEST_MATS_BATCH_CORRECTED_BMC[[i]]<-test_mat_batch_corrected_bmc$xadj
  M1_BATCH_CORRECTED_BMC[[i]]<-m1_batch_corrected_bmc$xadj
  M2_BATCH_CORRECTED_BMC[[i]]<-m2_batch_corrected_bmc$xadj
  M3_BATCH_CORRECTED_BMC[[i]]<-m3_batch_corrected_bmc$xadj
  
  
  
  
  #RMSE
  rmse_vec_bmc <- rmse(test_mat, test_mat_batch, test_mat_batch_corrected_bmc$xadj, m_1_mat, m1_batch_corrected_bmc$xadj, m_2_mat, m2_batch_corrected_bmc$xadj, m_3_mat, m3_batch_corrected_bmc$xadj, test_mat_corrected_bmc$xadj)
  
  #gpca delta
  delta_vec_bmc<-gpca_delta(test_mat, test_mat_batch, test_mat_batch_corrected_bmc$xadj, m_1_mat, m1_batch_corrected_bmc$xadj, m_2_mat, m2_batch_corrected_bmc$xadj, m_3_mat, m3_batch_corrected_bmc$xadj)
  
  delta_output_bmc <- cbind(delta_output_bmc, delta_vec_bmc)
  RMSE_output_bmc <- cbind(RMSE_output_bmc, rmse_vec_bmc)
  
  #harman------------------------------------------------------------------------------------
  #HARMAN
  test_mat_corrected_harman <- harman(test_mat, expt=class_factor, batch_factor, limit=0.95)#data matrix-samples in columns and data values in rows
  test_mat_corrected_harman <- reconstructData(test_mat_corrected_harman)#reconstruct the corrected data
  
  test_mat_batch_corrected_harman <- harman(test_mat_batch, expt=class_factor, batch_factor, limit=0.95)#data matrix-samples in columns and data values in rows
  test_mat_batch_corrected_harman <- reconstructData(test_mat_batch_corrected_harman)#reconstruct the corrected data
  
  #***Since reconstructed data is similar to original data, no need run original data through harman again
  
  #apply batch correction HARMAN for m_1_mat,m_2_mat,m_3_mat with missing values imputed
  m1_batch_corrected_harman <- harman(m_1_mat, expt=class_factor, batch_factor, limit=0.95)
  m1_batch_corrected_harman <- reconstructData(m1_batch_corrected_harman)
  m2_batch_corrected_harman <- harman(m_2_mat, expt=class_factor, batch_factor, limit=0.95)
  m2_batch_corrected_harman <- reconstructData(m2_batch_corrected_harman)
  m3_batch_corrected_harman <- harman(m_3_mat, expt=class_factor, batch_factor, limit=0.95)
  m3_batch_corrected_harman <- reconstructData(m3_batch_corrected_harman)
  
  
  #SAVE DATA
  TEST_MATS_CORRECTED_HARMAN[[i]]<-test_mat_corrected_harman
  TEST_MATS_BATCH_CORRECTED_HARMAN[[i]]<-test_mat_batch_corrected_harman
  M1_BATCH_CORRECTED_HARMAN[[i]]<-m1_batch_corrected_harman
  M2_BATCH_CORRECTED_HARMAN[[i]]<-m2_batch_corrected_harman
  M3_BATCH_CORRECTED_HARMAN[[i]]<-m3_batch_corrected_harman
  
  
  
  
  
  
  #RMSE
  rmse_vec_harman <- rmse(test_mat, test_mat_batch, test_mat_batch_corrected_harman, m_1_mat, m1_batch_corrected_harman, m_2_mat, m2_batch_corrected_harman, m_3_mat, m3_batch_corrected_harman, test_mat_corrected_harman)
  
  #gpca delta
  delta_vec_harman<-gpca_delta(test_mat, test_mat_batch, test_mat_batch_corrected_harman, m_1_mat, m1_batch_corrected_harman, m_2_mat, m2_batch_corrected_harman, m_3_mat, m3_batch_corrected_harman)
  
  delta_output_harman <- cbind(delta_output_harman, delta_vec_harman)
  RMSE_output_harman <- cbind(RMSE_output_harman, rmse_vec_harman)
  
  #SVA------------------------------------------------------------------------------------------
  test_mat_batch_corrected_sva <- sva_function(test_mat_batch)
  
  test_mat_corrected_sva <- sva_function(test_mat)
  #run original data matrix through SVA for comparison with batch corrected data as SVA transform data values
  
  #apply batch correction SVA for m_1_mat,m_2_mat,m_3_mat with missing values imputed
  m1_batch_corrected_sva <- sva_function(m_1_mat)
  m2_batch_corrected_sva <- sva_function(m_2_mat)
  m3_batch_corrected_sva <- sva_function(m_3_mat)
  
  
  #SAVE DATA
  TEST_MATS_CORRECTED_SVA[[i]]<-test_mat_corrected_sva
  TEST_MATS_BATCH_CORRECTED_SVA[[i]]<-test_mat_batch_corrected_sva
  M1_BATCH_CORRECTED_SVA[[i]]<-m1_batch_corrected_sva
  M2_BATCH_CORRECTED_SVA[[i]]<-m2_batch_corrected_sva
  M3_BATCH_CORRECTED_SVA[[i]]<-m3_batch_corrected_sva
  
  
  
  
  
  #RMSE
  rmse_vec_sva<-rmse(test_mat, test_mat_batch, test_mat_batch_corrected_sva, m_1_mat, m1_batch_corrected_sva, m_2_mat, m2_batch_corrected_sva, m_3_mat, m3_batch_corrected_sva, test_mat_corrected_sva)
  
  #gpca delta
  delta_vec_sva<-gpca_delta(test_mat, test_mat_batch, test_mat_batch_corrected_sva, m_1_mat, m1_batch_corrected_sva, m_2_mat, m2_batch_corrected_sva, m_3_mat, m3_batch_corrected_sva)
  
  delta_output_sva <- cbind(delta_output_sva, delta_vec_sva)
  RMSE_output_sva <- cbind(RMSE_output_sva, rmse_vec_sva)
}
end_time <- Sys.time()
end_time - start_time#Time difference of 9.087292 mins





#DON'T RUN FOR PLOTS IF U R CHECKING FP STATS

















######################plot######################################
library(ggplot2)
##delete column 1 with all the zeroes
#combat
dim(delta_output)
delta_output <- delta_output[,-1]
dim(delta_output)

dim(RMSE_output)
RMSE_output <- RMSE_output[,-1]#delete column 1 with all the zeroes
dim(RMSE_output)

#BMC
dim(delta_output_bmc)
delta_output_bmc <- delta_output_bmc[,-1]
dim(delta_output_bmc)

dim(RMSE_output_bmc)
RMSE_output_bmc <- RMSE_output_bmc[,-1]#delete column 1 with all the zeroes
dim(RMSE_output_bmc)

#Harman
dim(delta_output_harman)
delta_output_harman <- delta_output_harman[,-1]
dim(delta_output_harman)

dim(RMSE_output_harman)
RMSE_output_harman <- RMSE_output_harman[,-1]#delete column 1 with all the zeroes
dim(RMSE_output_harman)

#SVA
dim(delta_output_sva)
delta_output_sva <- delta_output_sva[,-1]
dim(delta_output_sva)

dim(RMSE_output_sva)
RMSE_output_sva <- RMSE_output_sva[,-1]#delete column 1 with all the zeroes
dim(RMSE_output_sva)
dev.off()


#labels
lab<-c("batch", "batch corrected", 
              "m1 batch", "m1 batch corrected",
              "m2 batch", "m2 batch corrected", 
              "m3 batch", "m3 batch corrected")
colors = c(rep("black",2),rep("maroon",2),rep("dark green",2),rep("dark blue",2))

#gpca delta labels
glab<-c("true null", "batch", "batch corrected", 
        "m1 batch", "m1 batch corrected",
        "m2 batch", "m2 batch corrected", 
        "m3 batch", "m3 batch corrected")
gcolors = c("grey36",rep("black",2),rep("maroon",2),rep("dark green",2),rep("dark blue",2))

#combat--------------------------------------------------------------------------------
##RMSE
RMSE_output<-as.data.frame(RMSE_output)
write.table(RMSE_output, file="testout.txt", quote=F, sep="\t")

#ggplot
#stack(as.data.frame(t(RMSE_output)))#use stack to transform the dataframe
rmse_bp <-ggplot(data=stack(as.data.frame(t(RMSE_output))), aes(x = ind, y = values,))+
  geom_boxplot(color=colors) + ggtitle("ComBat") + ylab("RMSE") + xlab("data")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(color = colors, size=10, angle=30, vjust=.8, hjust=0.8))
 
#basic boxplot
boxplot(t(RMSE_output))



##gPCA
delta_output<-as.data.frame(delta_output)
write.table(delta_output, file="testout.txt", quote=F, sep="\t")

#ggplot
delta_bp<-ggplot(data=stack(as.data.frame(t(delta_output))), aes(x = ind, y = values,))+
  geom_boxplot(color=gcolors) + ggtitle("ComBat") + ylab("gPCA delta") + xlab("data")+
  scale_x_discrete(labels= glab)+theme(axis.text.x=element_text(color = gcolors, size=10, angle=30, vjust=.8, hjust=0.8))

#basic boxplot
boxplot(t(delta_output))

#BMC--------------------------------------------------------------------------------------
##RMSE
RMSE_output_bmc<-as.data.frame(RMSE_output_bmc)
write.table(RMSE_output_bmc, file="testout.txt", quote=F, sep="\t")

#ggplot
rmse_bp_bmc<-ggplot(data=stack(as.data.frame(t(RMSE_output_bmc))), aes(x = ind, y = values,))+
  geom_boxplot(color=colors) + ggtitle("BMC") + ylab("RMSE") + xlab("data")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(color = colors, size=10, angle=30, vjust=.8, hjust=0.8))


#basic boxplot
boxplot(t(RMSE_output_bmc))

##gPCA
delta_output_bmc<-as.data.frame(delta_output_bmc)
write.table(delta_output_bmc, file="testout.txt", quote=F, sep="\t")
#ggplot
delta_bp_bmc<-ggplot(data=stack(as.data.frame(t(delta_output_bmc))), aes(x = ind, y = values,))+
  geom_boxplot(color=gcolors) + ggtitle("BMC") + ylab("gPCA delta") + xlab("data")+
  scale_x_discrete(labels= glab)+theme(axis.text.x=element_text(color = gcolors, size=10, angle=30, vjust=.8, hjust=0.8))

#basic boxplot
boxplot(t(delta_output_bmc))


#Harman---------------------------------------------------------------------------------
##RMSE
RMSE_output_harman<-as.data.frame(RMSE_output_harman)
write.table(RMSE_output_harman, file="testout.txt", quote=F, sep="\t")

#ggplot
rmse_bp_harman<-ggplot(data=stack(as.data.frame(t(RMSE_output_harman))), aes(x = ind, y = values,))+
  geom_boxplot(color=colors) + ggtitle("Harman") + ylab("RMSE") + xlab("data")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(color = colors, size=10, angle=30, vjust=.8, hjust=0.8))

#basic boxplot
boxplot(t(RMSE_output_harman))

##gPCA
delta_output_harman<-as.data.frame(delta_output_harman)
write.table(delta_output_harman, file="testout.txt", quote=F, sep="\t")

#ggplot
delta_bp_harman<-ggplot(data=stack(as.data.frame(t(delta_output_harman))), aes(x = ind, y = values,))+
  geom_boxplot(color=gcolors) + ggtitle("Harman") + ylab("gPCA delta") + xlab("data")+
  scale_x_discrete(labels= glab)+theme(axis.text.x=element_text(color = gcolors, size=10, angle=30, vjust=.8, hjust=0.8))


#basic boxplot
boxplot(t(delta_output_harman))

#SVA--------------------------------------------------------------------------------
##RMSE
RMSE_output_sva<-as.data.frame(RMSE_output_sva)
write.table(RMSE_output_sva, file="testout.txt", quote=F, sep="\t")

#ggplot
rmse_bp_sva<-ggplot(data=stack(as.data.frame(t(RMSE_output_sva))), aes(x = ind, y = values,))+
  geom_boxplot(color=colors) + ggtitle("SVA") + ylab("RMSE") + xlab("data")+
  scale_x_discrete(labels= lab)+theme(axis.text.x=element_text(color = colors, size=10, angle=30, vjust=.8, hjust=0.8))

#basic boxplot
boxplot(t(RMSE_output_sva))

##gPCA
delta_output_sva<-as.data.frame(delta_output_sva)
write.table(delta_output_sva, file="testout.txt", quote=F, sep="\t")

#ggplot
delta_bp_sva<-ggplot(data=stack(as.data.frame(t(delta_output_sva))), aes(x = ind, y = values,))+
  geom_boxplot(color=gcolors) + ggtitle("SVA") + ylab("gPCA delta") + xlab("data")+
  scale_x_discrete(labels= glab)+theme(axis.text.x=element_text(color = gcolors, size=10, angle=30, vjust=.8, hjust=0.8))


#basic boxplot
boxplot(t(delta_output_sva))


#EVERYTHING------------------------------------------------------------------------------
library(grid)
require(gridExtra)

#NOTE IF ERROR MESSAGE:
#Warning message: In makeContext(x) : reached elapsed time limit
#USE: dev.off()

#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
grid.arrange(rmse_bp, rmse_bp_bmc, rmse_bp_harman, rmse_bp_sva, ncol=4,
             top = textGrob("RMSE for Simulated Data with Global Additive + Multiplicative Batch Effects (10x)",gp=gpar(fontsize=16,font=3)))

grid.arrange(delta_bp, delta_bp_bmc, delta_bp_harman, delta_bp_sva, ncol=4,
             top = textGrob("gPCA delta for Simulated Data with Global Additive + Multiplicative Batch Effects (10x)",gp=gpar(fontsize=16,font=3)))




